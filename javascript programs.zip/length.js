let arr=[1,2,3,4];
console.log(arr.length);