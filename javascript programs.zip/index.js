let age = 28;
let d1=false;
if(age < 18 || d1==false){
    console.log("you can drive");

}else{
    console.log("you can not drive");
}