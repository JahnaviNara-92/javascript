let Names=['janu','heena,','indu','bindu','prashu','manasa','pooja'];
console.log(Names[0]);
console.log(Names[3]);
console.log(Names[5]);