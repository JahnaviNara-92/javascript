const person = { Name: "janu", age: 23, city:"kadapa" };
// destructuring the object
const{Name, age, city} = person;
console.log(Name); // output:janu
console.log(age); //output:23
console.log(city); //output:kadapa