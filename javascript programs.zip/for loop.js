let number=5;
for(let i=1; i<=5; i++){
    console.log("Number:"+i);
} 
